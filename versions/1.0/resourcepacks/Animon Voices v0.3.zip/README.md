# Animemon voices

Animon Voices Pack by Sal7y

This pack is for cobblemon and adds anime voice overs into the game


## Disclaimer

This Pokémon sounds pack is an unofficial fan-made project and is not affiliated with, endorsed, sponsored, or approved by Nintendo, Game Freak, or The Pokémon Company. Pokémon and all related characters, names, and content are trademarks of their respective owners. This sound pack is intended for non-commercial, educational, or personal use only and does not intend to infringe on any copyrights. If you are the copyright holder and would like any content removed, please contact us and we will comply promptly.

Pokémon is the property of Nintendo, Creatures Inc., and Game Freak. Assets included are distributed with the intention of criticism and entertainment as protected by Section 107 of the Copyright Act. The rights to the property are reserved by ©2024 Pokémon. ©1995 - 2024 Nintendo/Creatures Inc./GAME FREAK inc. TM, and ®Nintendo.

## License

Effective Date: 27/07/2024

1. License Grant
By downloading, using, or distributing the Cobblemon Voices Pack, you agree to the terms of this license agreement. The creator ("Licensor") grants you a non-exclusive, non-transferable, revocable license to use the Pack for personal use only.

2. Restrictions
You may not:
Modify, adapt, or create derivative works based on the Pack without explicit written permission from the Licensor

3. Ownership
The Licensor retains all rights, title, and interest in and to the Pack, including all intellectual property rights. This license does not grant you any ownership rights to the Pack.

## Author
Sal7y
