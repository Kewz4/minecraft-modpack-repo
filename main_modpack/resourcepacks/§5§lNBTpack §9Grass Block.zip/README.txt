NBTpack - New Better Textures Resource Pack made by Devu Projects

Refers to: NBTpack 1.5.15 - The Harmonic Update - Peak of Underground part 2, all the related Plugins and any version forward until any changes are made to the file.

Official social media and channels:
▮Youtube: https://www.youtube.com/@DevuProjects
▮Twitter: https://twitter.com/DevuProjects
▮Instagram: https://www.instagram.com/devuprojects/
▮Planet Minecraft: https://www.planetminecraft.com/member/devu_projects/
▮Curseforge: https://www.curseforge.com/members/deevuu/projects
▮Modrinth: https://modrinth.com/user/DevuProjects
No other official channels or social media

=====================================================================================================
TOU - Terms of use

By playing with NBTpack, or any of its Plugins you agree to observe the rules written in TOU

If you did anything that breaks TOU now, but back then it wasn't there, then that rule break doesn't matter

If you wouldn't like to accept the rules of TOU, stop using this pack and delete it from your drive



As a player / resource pack maker / writer you're allowed to:

●Play with resource pack

●Share resource pack to other players with mention of author and link to the official download page*
	*Official download pages:	
	https://www.planetminecraft.com/texture-pack/nbtpack-new-better-textures-texture-pack/
	https://www.curseforge.com/minecraft/texture-packs/nbtpack-java-edition and their corresponding Plugin links
●Use pack as inspiration for your pack, but need to mention this pack as inspiration*
	*Using NBTpack textures to create your own is meant as inspiration and using pack assets and almost completly identical textures is not meant as inspiration

●Modify the pack for personal use if modifications don't break the rules of server if using in multiplayer

●Create fan-made plugins


As a player / resource pack maker / writer you're NOT allowed to:

●Share resource pack while claiming to be an author

●Share resource pack using download soucre other than planetminecraft or curseforge links

●Use pack content and distribute edited / your pack as your own

●Use pack content and distribute edited / your pack even if original author in mentioned

●Use pack to hide multiplayer server's rule-breaking functionalities (such as x-ray) 

●Modify the pack and distribute as your own

●Modify the pack and distribute even if original author in mentioned

●Monetize the pack or earn money by using it*
	*Except for the videos or live streams where you're just plaing with NBTpack enabled and advertisements on website with article about pack, if the article is not breaking other TOU rules

●Add watermarks to any pack content*
	*"Pack content" is understand as every file contained in any of official NBTpack zipped files

●Using, sharing pack or acting in any way that may or to make people think pack is yours*
	*If people think pack is yours and it's not your fault, you just should clarify you're not the author

●Redistribute parts of the core pack as separated fan-made plugins



=====================================================================================================

How to install:
1.Put the downloaded file into your resourcepacks folder in .minecraft (%appdata%/.minecraft is the location unless you're using a pirated, so called "non-premium", version of the game or you've change the path manually)
2.You're ready to play with the pack once you select it in the game.

=====================================================================================================

Official pack files include:
pack assets
README file
Updatelog file
Changelog file

If you find a version without any of those file or with files not mentioned above, you're allowed and encouraged to contact via e-mail or twitter in order to inform about the problem and send form where you've downloaded the pack
e-mail: devu.contact.mail@gmail.com
twitter: DevuProjects

=====================================================================================================
What are NBTpack Plugins
Plugins are some kind of customisable options, that user may change to mach own preferences, previously known as Expansions. Most of them can work standalone. List of the plugins can be found in the official article containing downloadable files.

=====================================================================================================
Credits:
	NBTpack Base:
	★Kayteq - iron and diamond swords shape creator, some of the splashes originator
